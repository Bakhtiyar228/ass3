public class EbayService {
    public void makePayment(double amount) {
        System.out.println("Paid $" + amount + " via Ebay.");
    }
}
