public interface PaymentProcessor {
    void pay(double amount);
}
