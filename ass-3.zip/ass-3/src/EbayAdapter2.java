public class EbayAdapter2 implements PaymentProcessor {
    private EbayService2 ebayService;
    public EbayAdapter2(EbayService2 ebayService) {
        this.ebayService = ebayService;
    }
    @Override
    public void pay(double amount) {
        ebayService.chargePayment(amount);
    }
}
