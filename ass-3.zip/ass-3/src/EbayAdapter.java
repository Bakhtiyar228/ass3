public class EbayAdapter implements PaymentProcessor {
    private EbayService ebayService;
    public EbayAdapter(EbayService ebayService) {
        this.ebayService = ebayService;
    }
    @Override
    public void pay(double amount) {
        ebayService.makePayment(amount);
    }
}
