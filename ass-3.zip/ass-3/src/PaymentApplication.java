public class PaymentApplication {
    public static void main(String[] args) {
        PaymentProcessor ebayProcessor = new EbayAdapter(new EbayService());
        PaymentProcessor ebayProcessor2 = new EbayAdapter2(new EbayService2());
        double amount = 100.0;
        ebayProcessor.pay(amount);
        ebayProcessor2.pay(amount);
    }
}
