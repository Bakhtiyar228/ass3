public class EbayService2 {
    public void chargePayment(double amount) {
        System.out.println("Charged $" + amount + " using Ebay.");
    }
}
